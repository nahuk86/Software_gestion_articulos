﻿namespace Abstractions;

public class Class1
{

}
