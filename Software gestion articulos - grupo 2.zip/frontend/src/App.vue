<template>
  <div id="app">
    <Articulo />
  </div>
</template>

<script>
import Articulo from './components/Articulo.vue'

export default {
  name: 'App',
  components: {
    Articulo
  }
}
</script>

<style>

</style>
